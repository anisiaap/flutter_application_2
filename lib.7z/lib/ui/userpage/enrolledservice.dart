import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_application_2/model/event.dart';
import '../../model/eventservice.dart'; // Import EventService

class EnrolledService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final EventService _eventService = EventService(); // Initialize EventService

  Future<List<Event>> getEnrolledEvents(String userEmail) async {
    try {
      // Query Firestore to get enrolled events for the given user email
      QuerySnapshot querySnapshot = await _firestore
          .collection(userEmail)
          .get();

      // Initialize a list to store enrolled events
      List<Event> enrolledEvents = [];

      // Iterate through each document in the query snapshot
      for (DocumentSnapshot doc in querySnapshot.docs) {
        // Check if the 'enrolled' field is true
        if (doc['enrolled'] == true) {
          // Get the title of the enrolled event
          String eventTitle = doc.id;

          // Retrieve the event from the main events collection by its title
          Event? event = await _eventService.getEventByTitle(eventTitle);

          // If the event is found, add it to the list of enrolled events
          if (event != null) {
            enrolledEvents.add(event);
          }
        }
      }

      return enrolledEvents;
    } catch (e) {
      // Handle error if any
      print('Error retrieving enrolled events: $e');
      return []; // Return an empty list in case of error
    }
  }
}
