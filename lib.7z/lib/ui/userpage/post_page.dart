import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class PostPage extends StatefulWidget {
  @override
  _PostPageState createState() => _PostPageState();
}

class _PostPageState extends State<PostPage> {
  File? _image;
  String? _imageUrl;
  TextEditingController titleController = TextEditingController();
  TextEditingController descriptionController = TextEditingController();
  TextEditingController locationController = TextEditingController();
  TextEditingController durationController = TextEditingController();
  TextEditingController punchLine1Controller = TextEditingController();
  TextEditingController punchLine2Controller = TextEditingController();

  List<String> categoryIds = [];

  Future<void> _pickImage(ImageSource source) async {
    final pickedFile = await ImagePicker().pickImage(source: source);

    setState(() {
      if (pickedFile != null) {
        _image = File(pickedFile.path);
      } else {
        print('No image selected.');
      }
    });

    if (_image != null) {
      // Upload image to Firebase Storage
      Reference referenceDirImages =
      FirebaseStorage.instance.ref().child('images');
      Reference referenceImageToUpload = referenceDirImages
          .child(DateTime.now().millisecondsSinceEpoch.toString());

      try {
        await referenceImageToUpload.putFile(_image!);
        _imageUrl = await referenceImageToUpload.getDownloadURL();
      } catch (error) {
        print('Error uploading image: $error');
      }
    }
  }

  Future<void> _submit() async {
    if (_image == null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Please select an image')));
      return;
    }

    if (titleController.text.isEmpty ||
        descriptionController.text.isEmpty ||
        locationController.text.isEmpty ||
        durationController.text.isEmpty ||
        punchLine1Controller.text.isEmpty ||
        punchLine2Controller.text.isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Please fill all fields')));
      return;
    }

    // Convert categoryIds list to a map with boolean values
    Map<String, bool> categories = {};
    categoryIds.forEach((categoryId) {
      categories[categoryId] = true;
    });

    // Construct dataToSave map
    Map<String, dynamic> dataToSave = {
      'title': titleController.text,
      'description': descriptionController.text,
      'location': locationController.text,
      'duration': durationController.text,
      'punchLine1': punchLine1Controller.text,
      'punchLine2': punchLine2Controller.text,
      'categoryIds': categoryIds,
      'imagePath': _imageUrl,
      'QA': [""], // Initialize with an empty array for Q&A
      'galleryImages': [""], // Initialize with an empty array for gallery images
      'date': DateTime.now(), // Add current timestamp
    };

    // Add QA
    // Note: You can add questions and answers to the 'qa' array similarly

    // Add Gallery Images
    // Note: You can add image URLs to the 'galleryImages' array similarly

    await FirebaseFirestore.instance.collection('Events').add(dataToSave);
    Navigator.pop(context);
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Post Page"),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            _image == null ? Text('No image selected.') : Image.file(_image!),
            ElevatedButton(
              onPressed: () => _pickImage(ImageSource.camera),
              child: Text('Select Image from Camera'),
            ),
            ElevatedButton(
              onPressed: () => _pickImage(ImageSource.gallery),
              child: Text('Select Image from Gallery'),
            ),
            SizedBox(height: 20),
            SizedBox(height: 20),
            // CheckboxListTile for each category option
            CheckboxListTile(
              title: Text("Food"),
              value: categoryIds.contains("food"),
              onChanged: (bool? value) {
                setState(() {
                  if (value != null && value) {
                    categoryIds.add("food");
                  } else {
                    categoryIds.remove("food");
                  }
                });
              },
            ),
            CheckboxListTile(
              title: Text("Music"),
              value: categoryIds.contains("music"),
              onChanged: (bool? value) {
                setState(() {
                  if (value != null && value) {
                    categoryIds.add("music");
                  } else {
                    categoryIds.remove("music");
                  }
                });
              },
            ),
            CheckboxListTile(
              title: Text("Culture"),
              value: categoryIds.contains("culture"),
              onChanged: (bool? value) {
                setState(() {
                  if (value != null && value) {
                    categoryIds.add("culture");
                  } else {
                    categoryIds.remove("culture");
                  }
                });
              },
            ),
            CheckboxListTile(
              title: Text("Politics"),
              value: categoryIds.contains("politics"),
              onChanged: (bool? value) {
                setState(() {
                  if (value != null && value) {
                    categoryIds.add("politics");
                  } else {
                    categoryIds.remove("politics");
                  }
                });
              },
            ),
            CheckboxListTile(
              title: Text("Health"),
              value: categoryIds.contains("health"),
              onChanged: (bool? value) {
                setState(() {
                  if (value != null && value) {
                    categoryIds.add("health");
                  } else {
                    categoryIds.remove("health");
                  }
                });
              },
            ),
            CheckboxListTile(
              title: Text("Sports"),
              value: categoryIds.contains("sports"),
              onChanged: (bool? value) {
                setState(() {
                  if (value != null && value) {
                    categoryIds.add("sports");
                  } else {
                    categoryIds.remove("sports");
                  }
                });
              },
            ),

            SizedBox(height: 20),
            TextField(
              controller: titleController,
              decoration: InputDecoration(labelText: 'Title'),
            ),
            TextField(
              controller: descriptionController,
              decoration: InputDecoration(labelText: 'Description'),
            ),
            TextField(
              controller: locationController,
              decoration: InputDecoration(labelText: 'Location'),
            ),
            TextField(
              controller: durationController,
              decoration: InputDecoration(labelText: 'Duration'),
            ),
            TextField(
              controller: punchLine1Controller,
              decoration: InputDecoration(labelText: 'Punch Line 1'),
            ),
            TextField(
              controller: punchLine2Controller,
              decoration: InputDecoration(labelText: 'Punch Line 2'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _submit,
              child: Text('Submit'),
            ),
          ],
        ),
      ),
    );
  }
}
