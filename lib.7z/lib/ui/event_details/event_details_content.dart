import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../model/event.dart';
import '../../model/guest.dart';
import '../../styleguide.dart';
import '../homepage/map.dart';

class EventDetailsContent extends StatefulWidget {
  @override
  _EventDetailsContentState createState() => _EventDetailsContentState();
}

class _EventDetailsContentState extends State<EventDetailsContent> {
  TextEditingController _questionController = TextEditingController();
  List<QuestionAnswer> _userQuestions = [];

  void _submitQuestion() {
    final String question = _questionController.text.trim();
    if (question.isNotEmpty) {
      setState(() {
        _userQuestions.add(QuestionAnswer(question: question));
        _questionController.clear();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final event = Provider.of<Event>(context);
    final screenWidth = MediaQuery.of(context).size.width;
    final themeData  = Theme.of(context);
    return SingleChildScrollView(
      child: Column(
        children: [
          SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                SizedBox(
                  height: 100,
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.2),
                  child: Text(
                    event.title,
                    style: eventWhiteTitleTextStyle,
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.24),
                  child: FittedBox(
                    child: Row(
                      children: <Widget>[
                        Text(
                          "-",
                          style: eventLocationTextStyle.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        Icon(
                          Icons.location_on,
                          color: Colors.white,
                          size: 15,
                        ),
                        SizedBox(
                          width: 5,
                        ),
                        Text(
                          event.location,
                          style: eventLocationTextStyle.copyWith(
                              color: Colors.white, fontWeight: FontWeight.w700),
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.24),
                  child: FittedBox(
                    child: Row(
                      children: <Widget>[
                        Text(
                          "-",
                          style: eventLocationTextStyle.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        Icon(
                          Icons.date_range_rounded,
                          color: Colors.white,
                          size: 20,
                        ),
                        SizedBox(
                          width: 5,
                        ),
                        Text(
                          DateFormat('dd MMMM yyyy').format(event.date), // Use DateFormat
                          style: eventLocationTextStyle.copyWith(
                              color: Colors.white, fontWeight: FontWeight.w700),
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: 75,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 16.0),
                  child: Text(
                    "GUESTS",
                    style: guestTextStyle,
                  ),
                ),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: <Widget>[
                      for (final guest in guests)
                        Padding(
                          padding: const EdgeInsets.all(8),
                          child: ClipOval(
                            child: Image.asset(
                              guest.imagePath,
                              width: 90,
                              height: 90,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: RichText(
                    text: TextSpan(children: [
                      TextSpan(
                        text: event.punchLine1,
                        style: punchLine1TextStyle,
                      ),
                      TextSpan(
                        text: event.punchLine2,
                        style: punchLine2TextStyle,
                      ),
                    ]),
                  ),
                ),
                if (event.description.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Text(
                      event.description,
                      style: eventLocationTextStyle,
                    ),
                  ),
                if (event.galleryImages.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(left: 16.0, top: 16, bottom: 16),
                    child: Text(
                      "GALLERY",
                      style: guestTextStyle,
                    ),
                  ),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: <Widget>[
                      for (final galleryImagePath in event.galleryImages)
                        Container(
                          margin:
                          const EdgeInsets.only(left: 16, right: 16, bottom: 32),
                          child: ClipRRect(
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            child: Image.network(
                              galleryImagePath,
                              width: 180,
                              height: 180,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row( // Row for horizontal alignment
                    mainAxisAlignment: MainAxisAlignment.spaceBetween, // Space between buttons
                    children: [
                      ElevatedButton.icon(
                        onPressed: () {
                          // Add your 'add to favorite' functionality here
                        },
                        icon: Icon(Icons.star_border, color: Colors.white),
                        label: Text('Add to Favorite', style: TextStyle(color: Colors.white)),
                        style: ElevatedButton.styleFrom(backgroundColor: themeData.primaryColor),
                      ),
                      ElevatedButton.icon(
                        onPressed: () {

                          // Add your 'go to event' functionality here
                        },
                        icon: Icon(Icons.directions, color: Colors.white),
                        label: Text('Go to Event', style: TextStyle(color: Colors.white)),
                        style: ElevatedButton.styleFrom(backgroundColor: themeData.primaryColor),
                      ),
                    ],
                  ),
                ),
                // Q&A Section
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(
                    "Q&A",
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                ),

                // Q&A Section
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        "Q&A",
                        style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                      ),
                      if (event.qa != null && event.qa.isNotEmpty) // Check if event.qa is not null and not empty
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: event.qa!.map((question) { // Use map to create widgets for each question
                            return Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Q: $question",
                                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                                ),
                                SizedBox(height: 16),
                              ],
                            );
                          }).toList(),
                        ),
                    ],
                  ),
                ),

                // User input section
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(
                    "Ask a question:",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ),
                SizedBox(height: 8),
                TextField(
                  controller: _questionController,
                  decoration: InputDecoration(
                    hintText: "Type your question here...",
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 8),
                ElevatedButton(
                  onPressed: _submitQuestion,
                  child: Text("Submit"),
                ),
                // User submitted questions
                if (_userQuestions.isNotEmpty)
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: 16),
                      Text(
                        "Your Questions:",
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 8),
                      for (final userQuestion in _userQuestions)
                        Text(
                          userQuestion.question,
                          style: TextStyle(fontSize: 16),
                        ),
                    ],
                  ),
              ],
            ),
          ),
          SizedBox(
            height: 300, // Adjust the height as needed
            width: double.infinity, // Take the full width available
            child: MapSample(), // Use any widget you want here
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _questionController.dispose();
    super.dispose();
  }
}

class QuestionAnswer {
  final String question;
  final String answer;

  QuestionAnswer({
    required this.question,
    this.answer = '', // Providing a default value for the answer
  });
}
