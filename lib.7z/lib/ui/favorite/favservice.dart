import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_application_2/model/event.dart';
import '../../model/eventservice.dart'; // Import EventService

class FavoriteService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final EventService _eventService = EventService(); // Initialize EventService

  Future<List<Event>> getFavoriteEvents(String userEmail) async {
    try {
      // Query Firestore to get favorite events for the given user email
      QuerySnapshot querySnapshot = await _firestore
          .collection(userEmail)
          .get();

      // Initialize a list to store favorite events
      List<Event> favoriteEvents = [];

      // Iterate through each document in the query snapshot
      for (DocumentSnapshot doc in querySnapshot.docs) {
        // Check if the 'favorite' field is true
        if (doc['favorite'] == true) {
          // Get the title of the favorite event
          String eventTitle = doc.id;

          // Retrieve the event from the main events collection by its title
          Event? event = await _eventService.getEventByTitle(eventTitle);

          // If the event is found, add it to the list of favorite events
          if (event != null) {
            favoriteEvents.add(event);
          }
        }
      }

      return favoriteEvents;
    } catch (e) {
      // Handle error if any
      print('Error retrieving favorite events: $e');
      return []; // Return an empty list in case of error
    }
  }
}
